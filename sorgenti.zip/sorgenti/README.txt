
All'interno della cartella "Risultati analisi territoriale" vi sono tutte le tabelle
e i grafici utilizzati nell'analisi della distribuzione territoriale dei progetti.

La cartella contiene tre sotto cartelle:
-Risultati Big Data Analytics
-Risultati Cloud Computing 
-Risultati Cybersecurity

Ognuna di queste cartelle contiene i seguenti file:
-comuni.csv, contenente la tabella relativa alla distribuzione dei progetti 
della tecnologia presa in esame a livello comunale;
-comuni.pdf, contenente i grafici ottenuti a partire dall'analisi a livello
comunale;
-province.csv, contenente la tabella relativa alla distribuzione dei progetti 
della tecnologia presa in esame a livello provinciale;
-province.pdf, contenente i grafici ottenuti a partire dall'analisi a livello
provinciale;
-regioni.csv, contenente la tabella relativa alla distribuzione dei progetti 
della tecnologia presa in esame a livello regionale;
-regioni.pdf, contenente i grafici ottenuti a partire dall'analisi a livello
regionale.

La cartella "Risultati analisi territoriale" contiene anche le query in linguaggio
SQL utilizzate per generare i file CSV già citati.

La cartella "Risultati analisi territoriale" contiene anche i seguenti file:
-situazione_nazionale.csv, contenente la tabella relativa alla distribuzione
dei progetti considerati a livello nazionale;
-situazione_nazionale.pdf, contenente i grafici ottenuti a partire dall'analisi a livello
nazionale.
